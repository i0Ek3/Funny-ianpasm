﻿V4 version, DLL method fully automatic activation

Quiet mode (no prompts or message windows pop up):
Rename gatherosstate.exe to gatherosstate.quiet.exe at before running it.

#1.  Extract files to any directory

#2.  Create sku.txt , If it is a three-line format, the value of the three lines will be used.
       three-line format TXT content example:  

         first line(product key)------------------------xxxxx-xxxxx-xxxxx-xxxxx-xxxxx
         second line(SKU value)----------------------125
         third line(Channel value)--------------------Volume:GVLK
         HWID Channel value: Retail
         KMS38 Channel value:Volume:GVLK
	
         OR, just write KEY in the first line
         first line(product key)------------------------xxxxx-xxxxx-xxxxx-xxxxx-xxxxx
         If it is a one-line format, the values ​​of SKU and Channel will be read from OS after the KEY is automatically installed.

#3.   Double-click gatherosstate.exe or gatherosstateLTSB15.exe(just LTSB 2015) to wait for automatic activation.
        which is expected to be around 10-30 seconds. 
        Because slc.dll will install product key and online activation OS (just HWID method) , it will take some times.

When completed, a result file is generated:Result.txt
Result file content example:

Product KEY	xxxxx-xxxxx-xxxxx-xxxxx-xxxxx
SKU		4
Channel		Retail

2019-02-23 23:52:05  Applying GenuineTicket.xml...
2019-02-23 23:52:05  Activating system...
2019-02-23 23:52:08  Done.
